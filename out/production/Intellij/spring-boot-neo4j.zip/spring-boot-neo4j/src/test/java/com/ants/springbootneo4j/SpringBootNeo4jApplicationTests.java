package com.ants.springbootneo4j;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootNeo4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
