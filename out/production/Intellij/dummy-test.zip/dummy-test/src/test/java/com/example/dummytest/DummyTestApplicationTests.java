package com.example.dummytest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DummyTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
