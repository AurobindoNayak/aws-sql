package com.ants.aws.awssql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsSqlApplication.class, args);
	}

}
