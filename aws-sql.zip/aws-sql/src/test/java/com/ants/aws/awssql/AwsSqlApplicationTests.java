package com.ants.aws.awssql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsSqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
